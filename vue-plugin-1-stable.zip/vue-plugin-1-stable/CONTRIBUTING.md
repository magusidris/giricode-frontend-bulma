# Contributing

This plugin is designed to be small and simple, but we're also open to possible contributions and improvements.

Please open an issue first to discuss your ideas.
