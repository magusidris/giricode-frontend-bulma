## 1.0.1

- Publishing 1.0 was weird, just wanting to make sure the correct code was on NPM.

## 1.0.0

- Update to the newer Highlight.js `highlight` API.
- Clarify in README this is for Vue.js 2.0

## 0.9.0

- Original release
- Code split out from the original Highlight.js package